Thanks for downloading CloneSmasher.ml v1
Gameplay: https://youtu.be/rF0zRDfO9GM
Make sure you have node.js and tampermonkey installed!
http://nodejs.org
https://tampermonkey.net/
If you need help installing or want me to bot a game, DM me on discord DaRealSh0T#6008
To install, open "install.bat" if your on windows or "install - LINUX.sh" if you are on linux.
After installing, to start open "start.bat" if your on windows or "start - LINUX.sh" if your on linux.
To edit the keybinds, open userscript.js and look for "window.botConfig" (line 27)
Also don't forget to update the proxys daily, put http proxys in "http.txt", and put socks5 proxys in "socks.txt".